/**
 * @file Home.tsx
 * @description SAP S/4HANA × MK Smart — Feasibility Dashboard (static layout, cleaned up).
 */

import type { FC, ReactNode } from 'react'

/**
 * @description Generic section wrapper for dashboard blocks.
 */
const SectionCard: FC<{ title: string; icon?: string; children: ReactNode }> = ({
  title,
  icon,
  children,
}) => (
  <section className="rounded-xl border border-slate-200 bg-white/80 p-6 shadow-sm backdrop-blur">
    <div className="mb-4 flex items-center gap-2">
      {icon && (
        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-slate-900 text-sm text-white">
          {icon}
        </span>
      )}
      <h2 className="text-lg font-semibold text-slate-900">{title}</h2>
    </div>
    {children}
  </section>
)

/**
 * @description Simple metric card for key numbers.
 */
const MetricCard: FC<{
  label: string
  value: string
  detail?: string
  tone?: 'danger' | 'warning' | 'success' | 'neutral'
}> = ({ label, value, detail, tone = 'neutral' }) => {
  const toneClasses: Record<string, string> = {
    danger: 'border-red-200 bg-red-50',
    warning: 'border-amber-200 bg-amber-50',
    success: 'border-emerald-200 bg-emerald-50',
    neutral: 'border-slate-200 bg-slate-50',
  }

  return (
    <div className={`flex flex-col justify-between rounded-lg border p-4 text-sm ${toneClasses[tone]}`}>
      <p className="mb-1 text-xs font-medium uppercase tracking-wide text-slate-500">
        {label}
      </p>
      <p className="text-lg font-semibold text-slate-900">{value}</p>
      {detail && <p className="mt-1 text-xs text-slate-600">{detail}</p>}
    </div>
  )
}

/**
 * @description Badge showing risk severity.
 */
const RiskBadge: FC<{ level: 'Fatal' | 'Cao' | 'Trung bình' | 'Thấp' }> = ({ level }) => {
  const map: Record<string, { label: string; classes: string }> = {
    Fatal: { label: '🔴 Fatal Risk', classes: 'bg-red-100 text-red-800' },
    Cao: { label: '🟠 Rủi ro Cao', classes: 'bg-amber-100 text-amber-800' },
    'Trung bình': { label: '🟡 Rủi ro TB', classes: 'bg-yellow-100 text-yellow-800' },
    Thấp: { label: '🟢 Rủi ro Thấp', classes: 'bg-emerald-100 text-emerald-800' },
  }

  const item = map[level]

  return (
    <span className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-medium ${item.classes}`}>
      {item.label}
    </span>
  )
}

/**
 * @description Main dashboard page for SAP S/4HANA × MK Smart feasibility.
 */
const HomePage: FC = () => {
  return (
    <div className="min-h-screen bg-slate-900/95 text-slate-900">
      <div className="mx-auto flex max-w-6xl flex-col gap-8 px-4 py-10">
        {/* Header */}
        <header className="flex flex-col gap-4 rounded-2xl border border-slate-700 bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800 p-6 text-slate-100 shadow-lg">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.25em] text-emerald-300">
                Feasibility Dashboard
              </p>
              <h1 className="mt-2 text-2xl font-bold tracking-tight">
                SAP S/4HANA × MK Smart — Đánh giá Tính Khả thi Triển khai
              </h1>
              <p className="mt-1 text-sm text-slate-300">
                Phân tích đa chiều · Context: MK Group + FPT IS Knowledge Base · Tháng 6/2025
              </p>
            </div>
            <div className="flex flex-col items-end text-right text-sm">
              <p className="text-xs text-slate-400">Khuyến nghị tổng thể</p>
              <p className="text-sm font-semibold text-red-300">
                ⚠️ PCI DSS Risk: Critical
              </p>
              <p className="text-xs text-slate-300">
                FPT IS: <span className="font-semibold text-rose-200">Không khuyến nghị triển khai SAP S/4HANA cho MK Smart ở thời điểm này</span>
              </p>
            </div>
          </div>

          <div className="mt-4 grid gap-4 md:grid-cols-4">
            <MetricCard
              label="Điểm Khả thi Tổng thể"
              value="4.5 / 10"
              detail="Rủi ro Cao · Không khuyến nghị ở thời điểm hiện tại"
              tone="danger"
            />
            <MetricCard
              label="TCO 3 năm (SAP On-premise)"
              value="$2–5M"
              detail="↑ 8–17× so với FPT IS"
              tone="warning"
            />
            <MetricCard
              label="Timeline triển khai"
              value="13–20 tháng"
              detail="So với 8–20 tuần/module của FPT IS"
              tone="warning"
            />
            <MetricCard
              label="PCI DSS & Năng lực Partner"
              value="Rủi ro rất cao"
              detail="6–12T re-certify PCI sau go-live · 0 SAP partner VN có kinh nghiệm card manufacturing"
              tone="danger"
            />
          </div>
        </header>

        {/* Ma trận khả thi + Điểm trung bình */}
        <SectionCard title="Ma trận Khả thi — 7 Chiều Đánh giá" icon="📡">
          <p className="mb-4 text-xs text-slate-600">
            Điểm 1–10 theo từng tiêu chí · 10 = hoàn toàn khả thi
          </p>
          <div className="grid gap-6 md:grid-cols-[2fr,1.2fr]">
            <div className="grid gap-3 text-sm">
              <div className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2">
                <span className="text-slate-700">💰 Chi phí</span>
                <span className="font-semibold text-slate-900">3 / 10</span>
              </div>
              <div className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2">
                <span className="text-slate-700">⏱️ Timeline</span>
                <span className="font-semibold text-slate-900">4 / 10</span>
              </div>
              <div className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2">
                <span className="text-slate-700">🏭 Kỹ thuật SAP PP</span>
                <span className="font-semibold text-slate-900">7 / 10</span>
              </div>
              <div className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2">
                <span className="text-slate-700">🔧 Card Personalization</span>
                <span className="font-semibold text-slate-900">2 / 10</span>
              </div>
              <div className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2">
                <span className="text-slate-700">🔐 PCI DSS Compliance</span>
                <span className="font-semibold text-slate-900">2 / 10</span>
              </div>
              <div className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2">
                <span className="text-slate-700">🇻🇳 Compliance Việt Nam</span>
                <span className="font-semibold text-slate-900">4 / 10</span>
              </div>
              <div className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2">
                <span className="text-slate-700">👥 Nội bộ sẵn sàng</span>
                <span className="font-semibold text-slate-900">3 / 10</span>
              </div>
            </div>

            <div className="flex flex-col justify-between rounded-xl bg-slate-900 p-4 text-slate-50">
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-slate-400">
                  Tổng điểm trung bình
                </p>
                <p className="mt-1 text-3xl font-bold">
                  3.6 <span className="text-base font-medium text-slate-300">/ 10</span>
                </p>
                <p className="mt-2 text-xs text-slate-300">
                  Ngưỡng rủi ro cao · Chỉ nên xem xét lại khi mô hình vận hành và PCI DSS được tối ưu hoá.
                </p>
              </div>
              <div className="mt-4 h-1.5 w-full rounded-full bg-slate-700">
                <div
                  className="h-1.5 rounded-full bg-red-400"
                  style={{ width: '36%' }}
                />
              </div>
            </div>
          </div>
        </SectionCard>

        {/* So sánh chi phí TCO 3 năm */}
        <SectionCard
          title="So sánh Chi phí TCO 3 năm — SAP S/4HANA vs. FPT IS Portfolio"
          icon="💰"
        >
          <div className="grid gap-6 lg:grid-cols-2">
            {/* SAP */}
            <div className="rounded-lg bg-slate-50 p-4 text-sm">
              <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                SAP S/4HANA Cloud Public (RISE) — Option A
              </p>
              <ul className="space-y-1 text-slate-700">
                <li>
                  <span className="font-medium">License/Subscription / năm:</span>{' '}
                  $150K–300K
                </li>
                <li>
                  <span className="font-medium">Implementation Partner:</span>{' '}
                  $400K–800K
                </li>
                <li>
                  <span className="font-medium">PCI DSS Security Layer (bổ sung):</span>{' '}
                  $200K–500K
                </li>
                <li>
                  <span className="font-medium">VN Localization Add-ons:</span>{' '}
                  $80K–200K
                </li>
                <li>
                  <span className="font-medium">Change Management &amp; Training:</span>{' '}
                  $100K–200K
                </li>
              </ul>
              <div className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-800">
                <p className="font-semibold">TOTAL TCO 3 NĂM (Option A): $1.2 – 2.1M USD</p>
                <p className="text-xs">≈ 30 – 52 tỷ VNĐ</p>
              </div>
            </div>

            {/* FPT IS */}
            <div className="rounded-lg bg-slate-50 p-4 text-sm">
              <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                FPT IS Portfolio (tương đương scope)
              </p>
              <ul className="space-y-1 text-slate-700">
                <li>
                  <span className="font-medium">akaMES (MES + QC + Tracking):</span>{' '}
                  $80K–150K
                </li>
                <li>
                  <span className="font-medium">FPT.eInvoice + eContract:</span>{' '}
                  $20K–50K
                </li>
                <li>
                  <span className="font-medium">EagleEye PCI DSS (QSA + MDR):</span>{' '}
                  $60K–120K
                </li>
                <li>
                  <span className="font-medium">FPT.iHRP + FPT.dPlat Finance:</span>{' '}
                  $40K–80K
                </li>
                <li>
                  <span className="font-medium">Implementation &amp; Training:</span>{' '}
                  $50K–100K
                </li>
              </ul>
              <div className="mt-4 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-900">
                <p className="font-semibold">TOTAL TCO 3 NĂM (FPT IS): $250K – 500K USD</p>
                <p className="text-xs">
                  ≈ 6 – 12.5 tỷ VNĐ · Tiết kiệm khoảng 80% so với SAP
                </p>
              </div>
            </div>
          </div>

          {/* Bar comparison */}
          <div className="mt-6 space-y-2">
            <p className="text-xs font-medium uppercase tracking-wide text-slate-500">
              So sánh tương đối — TCO trung bình 3 năm
            </p>
            <div className="space-y-3 text-xs text-slate-700">
              <div>
                <div className="mb-1 flex justify-between">
                  <span>SAP (Option A)</span>
                  <span className="font-semibold">$1,650,000</span>
                </div>
                <div className="h-2 w-full rounded-full bg-slate-200">
                  <div className="h-2 rounded-full bg-red-500" style={{ width: '80%' }} />
                </div>
              </div>
              <div>
                <div className="mb-1 flex justify-between">
                  <span>SAP (Option B)</span>
                  <span className="font-semibold">$3,500,000</span>
                </div>
                <div className="h-2 w-full rounded-full bg-slate-200">
                  <div className="h-2 rounded-full bg-red-700" style={{ width: '100%' }} />
                </div>
              </div>
              <div>
                <div className="mb-1 flex justify-between">
                  <span>FPT IS</span>
                  <span className="font-semibold">$375K</span>
                </div>
                <div className="h-2 w-full rounded-full bg-slate-200">
                  <div className="h-2 rounded-full bg-emerald-500" style={{ width: '20%' }} />
                </div>
              </div>
            </div>
          </div>
        </SectionCard>

        {/* Ma trận rủi ro triển khai */}
        <SectionCard title="Ma trận Rủi ro Triển khai" icon="⚠️">
          <div className="grid gap-4 md:grid-cols-2">
            {/* Fatal risks */}
            <article className="rounded-lg bg-slate-50 p-4 text-sm">
              <RiskBadge level="Fatal" />
              <h3 className="mt-2 text-sm font-semibold text-slate-900">
                Mất PCI DSS Certification
              </h3>
              <p className="mt-1 text-xs text-slate-700">
                CDE bị gián đoạn trong migration → MK Smart không được sản xuất thẻ ngân hàng 6–12
                tháng. Mất hợp đồng 80+ ngân hàng.
              </p>
            </article>
            <article className="rounded-lg bg-slate-50 p-4 text-sm">
              <RiskBadge level="Fatal" />
              <h3 className="mt-2 text-sm font-semibold text-slate-900">
                Card Personalization không có module native
              </h3>
              <p className="mt-1 text-xs text-slate-700">
                SAP không có workflow cho card personalization. Custom development tốn thêm
                $300K–$800K, không partner Việt Nam nào có kinh nghiệm.
              </p>
            </article>

            {/* High risks */}
            <article className="rounded-lg bg-slate-50 p-4 text-sm">
              <RiskBadge level="Cao" />
              <h3 className="mt-2 text-sm font-semibold text-slate-900">
                Budget overrun gần như chắc chắn
              </h3>
              <p className="mt-1 text-xs text-slate-700">
                70% dự án SAP trên thế giới bị overrun. Đặc thù ngành thẻ chip có thể cao hơn. Ước
                tính overrun: +30–80%.
              </p>
            </article>
            <article className="rounded-lg bg-slate-50 p-4 text-sm">
              <RiskBadge level="Cao" />
              <h3 className="mt-2 text-sm font-semibold text-slate-900">
                SLA vi phạm với 80+ ngân hàng
              </h3>
              <p className="mt-1 text-xs text-slate-700">
                Trong 13–20 tháng triển khai, gián đoạn bất kỳ → ảnh hưởng giao thẻ đúng hẹn →
                phạt hợp đồng nghiêm trọng.
              </p>
            </article>

            {/* Medium risks */}
            <article className="rounded-lg bg-slate-50 p-4 text-sm">
              <RiskBadge level="Trung bình" />
              <h3 className="mt-2 text-sm font-semibold text-slate-900">
                VN Compliance add-on chưa ổn định
              </h3>
              <p className="mt-1 text-xs text-slate-700">
                Partner VN cần build add-on eInvoice NĐ123, BHXH — chất lượng và timeline không
                đảm bảo như giải pháp native của FPT IS.
              </p>
            </article>
            <article className="rounded-lg bg-slate-50 p-4 text-sm">
              <RiskBadge level="Trung bình" />
              <h3 className="mt-2 text-sm font-semibold text-slate-900">
                Thiếu SAP competency nội bộ
              </h3>
              <p className="mt-1 text-xs text-slate-700">
                Cần 10–15 người SAP-trained. Chi phí build team $500K–$1M/năm. Rủi ro brain drain
                sau go-live.
              </p>
            </article>
            <article className="rounded-lg bg-slate-50 p-4 text-sm">
              <RiskBadge level="Trung bình" />
              <h3 className="mt-2 text-sm font-semibold text-slate-900">
                Chip OS tracking không có trong SAP
              </h3>
              <p className="mt-1 text-xs text-slate-700">
                MK Smart sở hữu chip OS độc quyền. SAP không có module quản lý firmware version
                tracking cho chip thẻ.
              </p>
            </article>

            {/* Low risk */}
            <article className="rounded-lg bg-slate-50 p-4 text-sm">
              <RiskBadge level="Thấp" />
              <h3 className="mt-2 text-sm font-semibold text-slate-900">
                SAP PP/QM/EWM hoạt động tốt
              </h3>
              <p className="mt-1 text-xs text-slate-700">
                Lamination, chip embedding, QC vật lý — SAP PP xử lý tốt. Đây là điểm mạnh rõ ràng
                của SAP trong case này.
              </p>
            </article>
          </div>
        </SectionCard>

        {/* Khả năng SAP S/4HANA — Mapping quy trình */}
        <SectionCard
          title="Khả năng SAP S/4HANA — Mapping theo Quy trình Sản xuất Thẻ Chip của MK Smart"
          icon="🔧"
        >
          <div className="overflow-x-auto rounded-lg border border-slate-200 bg-white">
            <table className="min-w-full border-collapse text-xs">
              <thead className="bg-slate-50 text-left text-[11px] uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="px-3 py-2 font-medium">Quy trình / Yêu cầu</th>
                  <th className="px-3 py-2 font-medium">SAP Module</th>
                  <th className="px-3 py-2 font-medium">Trạng thái</th>
                  <th className="px-3 py-2 font-medium">Ghi chú &amp; Thay thế</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-[13px]">
                <tr>
                  <td className="px-3 py-2">📦 BOM &amp; Routing quản lý</td>
                  <td className="px-3 py-2">PP / ENG</td>
                  <td className="px-3 py-2 text-emerald-700">✅ Tốt</td>
                  <td className="px-3 py-2">Standard SAP PP, hỗ trợ multi-level BOM.</td>
                </tr>
                <tr>
                  <td className="px-3 py-2">🏗️ Production Orders &amp; MRP</td>
                  <td className="px-3 py-2">PP / MRP</td>
                  <td className="px-3 py-2 text-emerald-700">✅ Tốt</td>
                  <td className="px-3 py-2">SAP PP/DS xử lý tốt capacity planning.</td>
                </tr>
                <tr>
                  <td className="px-3 py-2">🔬 Batch/Lot Tracking</td>
                  <td className="px-3 py-2">PP / QM</td>
                  <td className="px-3 py-2 text-emerald-700">✅ Tốt</td>
                  <td className="px-3 py-2">SAP Batch Management, GR/GI tracking.</td>
                </tr>
                <tr>
                  <td className="px-3 py-2">🧪 Quality Control (QM)</td>
                  <td className="px-3 py-2">QM</td>
                  <td className="px-3 py-2 text-emerald-700">✅ Tốt</td>
                  <td className="px-3 py-2">Inspection lots, usage decision tích hợp PP.</td>
                </tr>
                <tr>
                  <td className="px-3 py-2">🏬 Warehouse Management</td>
                  <td className="px-3 py-2">EWM</td>
                  <td className="px-3 py-2 text-emerald-700">✅ Tốt</td>
                  <td className="px-3 py-2">SAP EWM hỗ trợ secure storage zones.</td>
                </tr>
                <tr>
                  <td className="px-3 py-2">💳 Card Personalization Workflow</td>
                  <td className="px-3 py-2">—</td>
                  <td className="px-3 py-2 text-red-600">❌ Không có</td>
                  <td className="px-3 py-2">
                    Cần custom dev $300–800K · akaMES là giải pháp thay thế phù hợp.
                  </td>
                </tr>
                <tr>
                  <td className="px-3 py-2">🔐 PCI CDE Boundary trong ERP</td>
                  <td className="px-3 py-2">—</td>
                  <td className="px-3 py-2 text-red-600">❌ Không có</td>
                  <td className="px-3 py-2">SAP không phải PCI-scoped system · nên dùng EagleEye.</td>
                </tr>
                <tr>
                  <td className="px-3 py-2">🔗 Chain-of-Custody thẻ bảo mật</td>
                  <td className="px-3 py-2">WM / EWM</td>
                  <td className="px-3 py-2 text-amber-600">⚠️ Một phần</td>
                  <td className="px-3 py-2">
                    Cần customization thêm cho secure handling và audit trail chuyên sâu.
                  </td>
                </tr>
                <tr>
                  <td className="px-3 py-2">💾 Chip OS Version Tracking</td>
                  <td className="px-3 py-2">—</td>
                  <td className="px-3 py-2 text-red-600">❌ Không có</td>
                  <td className="px-3 py-2">
                    Cần custom hoặc akaMES/akaPLM để quản lý firmware version.
                  </td>
                </tr>
                <tr>
                  <td className="px-3 py-2">📋 VISA/MC Audit Trail Format</td>
                  <td className="px-3 py-2">—</td>
                  <td className="px-3 py-2 text-sky-700">🔧 Custom</td>
                  <td className="px-3 py-2">Cần ISV add-on, không native trong SAP.</td>
                </tr>
                <tr>
                  <td className="px-3 py-2">🚚 Secure Logistics Integration</td>
                  <td className="px-3 py-2">TM</td>
                  <td className="px-3 py-2 text-amber-600">⚠️ Một phần</td>
                  <td className="px-3 py-2">
                    SAP TM cơ bản · FPT.eTMS phù hợp hơn với bối cảnh Việt Nam.
                  </td>
                </tr>
                <tr>
                  <td className="px-3 py-2">🧾 Hóa đơn điện tử NĐ 123</td>
                  <td className="px-3 py-2">FI</td>
                  <td className="px-3 py-2 text-red-600">❌ Không native</td>
                  <td className="px-3 py-2">
                    Cần localization add-on · FPT.eInvoice là giải pháp native.
                  </td>
                </tr>
                <tr>
                  <td className="px-3 py-2">👥 HR &amp; Payroll Việt Nam</td>
                  <td className="px-3 py-2">HCM</td>
                  <td className="px-3 py-2 text-amber-600">⚠️ Một phần</td>
                  <td className="px-3 py-2">
                    SAP HCM cần add-on BHXH · FPT.iHRP đã có đầy đủ chức năng cho VN.
                  </td>
                </tr>
                <tr>
                  <td className="px-3 py-2">📊 Finance &amp; Controlling</td>
                  <td className="px-3 py-2">FI / CO</td>
                  <td className="px-3 py-2 text-emerald-700">✅ Tốt</td>
                  <td className="px-3 py-2">
                    SAP FI/CO là điểm mạnh, phù hợp cho tài chính &amp; controlling tập đoàn.
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="mt-3 flex flex-wrap gap-2 text-[11px] text-slate-600">
            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5">
              <span className="text-xs">✅</span> Tốt — SAP xử lý được native
            </span>
            <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5">
              <span className="text-xs">⚠️</span> Một phần — Cần customization
            </span>
            <span className="inline-flex items-center gap-1 rounded-full bg-red-50 px-2 py-0.5">
              <span className="text-xs">❌</span> Không có — Phải custom hoặc dùng giải pháp khác
            </span>
            <span className="inline-flex items-center gap-1 rounded-full bg-sky-50 px-2 py-0.5">
              <span className="text-xs">🔧</span> Custom ISV / partner add-on
            </span>
          </div>
        </SectionCard>
      </div>
    </div>
  )
}

export default HomePage
